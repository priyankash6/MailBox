﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
namespace mailbox
{
    public partial class resetpwd : System.Web.UI.Page
    {
        string UserId;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] == null)
            {
                Response.Redirect("index.aspx");
            }

            UserId = Session["UserId"].ToString(); 
        }

        protected void reset_here_Click(object sender, EventArgs e)
        {
            if (txtconpwd.Text == txtnewpwd.Text)
            {
                string strcon = ConfigurationManager.ConnectionStrings["MailboxConnectionString"].ConnectionString;

                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                SqlCommand com = new SqlCommand("update MailBoxUser set UserPassword='"+ txtnewpwd.Text +
                    "' where UserId=" + UserId +"and UserPassword='" +txtoldpwd.Text+ "'"
                    , con);

                try
                {
                    int rowsAffected = com.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {

                        lblsuccessmssg.Text = "Password Updated Successfully ";
                    }
                    else
                    {
                        lblsuccessmssg.Text = "Invalid Credentials ";
                    }

                }
                catch (Exception ex)
                {
                    lblsuccessmssg.Text = "Exception Occur " + ex;
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                lblsuccessmssg.Text = "Password Does not Match";
            }
        }

        
    }
}