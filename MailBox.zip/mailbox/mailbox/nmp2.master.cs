﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace mailbox
{
    public partial class nmp2 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Session["UserName"] = null;
            Session["UserId"] = null;
            Response.Redirect("index.aspx");
        }

        protected void resetpwd_Click(object sender, EventArgs e)
        {
            Response.Redirect("resetpwd.aspx");
        }

        protected void home_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }

        protected void compose_Click(object sender, EventArgs e)
        {
            Response.Redirect("compose.aspx");
        }

        protected void sent_Click(object sender, EventArgs e)
        {
            Response.Redirect("sent.aspx");
        }
    }
}