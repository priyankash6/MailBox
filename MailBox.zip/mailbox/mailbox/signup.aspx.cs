﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace mailbox
{
    public partial class signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void sign_up_here_Click(object sender, EventArgs e)
        {
            string strcon = ConfigurationManager.ConnectionStrings["MailboxConnectionString"].ConnectionString;

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand com = new SqlCommand("insert into MailBoxUser values( '" +
                txtemail.Text + "','" + txtpwd.Text + "','" + txtusername.Text +"')",con);
            try
            {
                int rowsAffected = com.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    lblsuccessmssg.Text = "Data Inserted Successfully";
                    Response.Redirect("signin.aspx");
                }
                else
                {
                    lblsuccessmssg.Text = "Data Cannot Inserted ";
                }

            }
            catch (Exception ex)
            {
                lblsuccessmssg.Text = "Exception Occur " + ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}