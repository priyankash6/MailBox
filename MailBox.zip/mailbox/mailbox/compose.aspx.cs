﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace mailbox
{
    public partial class compose : System.Web.UI.Page
    {
         
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] == null)
            {
                Response.Redirect("index.aspx");
            }

        }
        protected void compose_here_Click(object sender, EventArgs e)
        {
            int toUserId=-1;
            int id = Convert.ToInt32(Session["UserId"].ToString());
            string constr = ConfigurationManager.ConnectionStrings["MailboxConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            string query = "select UserId from MailBoxUser where UserEmail = '"+ txttouser.Text +"'";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr =cmd.ExecuteReader();
            while(dr.Read())
            {
                toUserId =Convert.ToInt32( dr["UserId"].ToString());
            }
            dr.Close();
            if (toUserId == -1)
            {
                lblsuccessmssg.Text = "Invalid User Id";
            }
            else
            {
                SqlCommand com = new SqlCommand("insert into Message values(" + toUserId +
                "," + id + ",'" + DateTime.Now + "','" + txtsub.Text.ToString() + "','" + txtmssg.Text.ToString() + "')"
                , con);




                try
                {
                    int rowsAffected = com.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        lblsuccessmssg.Text = "Message sent";
                        Response.Redirect("sent.aspx");
                    }
                    else
                    {
                        lblsuccessmssg.Text = "Message not sent";
                    }

                }
                catch (Exception ex)
                {
                    lblsuccessmssg.Text = "Exception Occur " + ex;
                }
                finally
                {
                    con.Close();
                }
            }
        }

        
    }
}