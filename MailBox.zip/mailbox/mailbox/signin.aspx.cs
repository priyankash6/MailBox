﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
namespace mailbox
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void sign_in_here_Click(object sender, EventArgs e)
        {
            string strcon = ConfigurationManager.ConnectionStrings["MailboxConnectionString"].ConnectionString;

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand com = new SqlCommand("select * from MailBoxUser where UserEmail='"
                + txtemail.Text + "'and UserPassword='" + txtpwd.Text +"'", con);
            
            try
            {
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    Session["UserName"] = reader["UserName"].ToString();
                    Session["UserId"] = reader["UserId"].ToString();

                }  
                if (reader.HasRows == true)
                {
                    
                    lblsuccessmssg.Text = "Login Successfull ";
                    Response.Redirect("home.aspx");
                }
                else
                {
                    lblsuccessmssg.Text = "Invalid Credentials ";
                }

            }
            catch (Exception ex)
            {
                lblsuccessmssg.Text = "Exception Occur " + ex;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
