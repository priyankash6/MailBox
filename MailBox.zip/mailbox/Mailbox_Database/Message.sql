USE [Mailbox]
GO

/****** Object:  Table [dbo].[Message]    Script Date: 8/5/2020 5:43:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Message](
	[MessageId] [int] IDENTITY(1,1) NOT NULL,
	[toUser] [int] NOT NULL,
	[fromUser] [int] NOT NULL,
	[TimeStame] [datetime] NOT NULL,
	[Subject] [varchar](300) NOT NULL,
	[Message] [varchar](7000) NOT NULL,
 CONSTRAINT [PK_Message] PRIMARY KEY CLUSTERED 
(
	[MessageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Message]  WITH CHECK ADD  CONSTRAINT [FK_Message_User] FOREIGN KEY([toUser])
REFERENCES [dbo].[MailBoxUser] ([UserId])
GO

ALTER TABLE [dbo].[Message] CHECK CONSTRAINT [FK_Message_User]
GO

ALTER TABLE [dbo].[Message]  WITH CHECK ADD  CONSTRAINT [FK_Message_User1] FOREIGN KEY([fromUser])
REFERENCES [dbo].[MailBoxUser] ([UserId])
GO

ALTER TABLE [dbo].[Message] CHECK CONSTRAINT [FK_Message_User1]
GO


